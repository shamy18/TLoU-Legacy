public interface HeroSelectionListener {
    void onHeroSelected(String sharedConstant, GameGUI gj);
}
