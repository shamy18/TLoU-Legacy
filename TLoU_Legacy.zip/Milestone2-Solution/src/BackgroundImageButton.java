import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.io.InputStream;

import javax.swing.ImageIcon;
import javax.swing.JButton;

public class BackgroundImageButton extends JButton {
    private Image backgroundImage;
    private Font customFont;

    public BackgroundImageButton(String imagePath) {
        super();
        setContentAreaFilled(false);
        setBackgroundImage(imagePath);
        setForeground(Color.WHITE);
        setCustomFont("font.ttf", Font.PLAIN, 25);
    }

    public void setBackgroundImage(String imagePath) {
        backgroundImage = new ImageIcon(imagePath).getImage();
    }

    public void setCustomFont(String fontName, int fontStyle, int fontSize) {
        try {
            InputStream inputStream = getClass().getResourceAsStream(fontName);
            Font font = Font.createFont(Font.TRUETYPE_FONT, inputStream);
            customFont = font.deriveFont(fontStyle, fontSize);
        } catch (Exception e) {
            e.printStackTrace();
            // Handle font loading error
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
        super.paintComponent(g);
    }

    @Override
    public Font getFont() {
        return customFont != null ? customFont : super.getFont();
    }
}