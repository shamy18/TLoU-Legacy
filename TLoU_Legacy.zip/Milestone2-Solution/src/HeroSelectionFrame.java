import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.*;
import java.io.File;
import engine.Game;
import javafx.scene.media.MediaPlayer;
import model.characters.Hero;
import javafx.embed.swing.JFXPanel;
import javafx.scene.media.Media;
import javax.swing.plaf.basic.BasicButtonUI;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

public class HeroSelectionFrame extends JFrame implements HeroSelectionListener {
    private JButton startButton;
    private JPanel heroSelectionPanel;
    public static final String HERO_SELECTION_COMPLETE = "HERO_SELECTION_COMPLETE";

    private MediaPlayer mediaPlayer;

    public HeroSelectionFrame() {
        super("Hero Selection");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1280, 720);
        setLocationRelativeTo(null);

        ImageIcon backgroundImage = new ImageIcon("background.jpg");
        JLabel backgroundLabel = new JLabel(backgroundImage);
        setContentPane(backgroundLabel);
        getContentPane().setLayout(new BorderLayout());

        JFXPanel fxPanel = new JFXPanel();

        String songPath = "maintheme.mp3";
        Media media = new Media(new File(songPath).toURI().toString());
        mediaPlayer = new MediaPlayer(media);
        mediaPlayer.setCycleCount(MediaPlayer.INDEFINITE);

        startButton = new JButton("Start");
        startButton.setPreferredSize(new Dimension(170, 60));
        startButton.setBorderPainted(false);
        startButton.setBackground(new Color(0, 0, 0));
        startButton.setOpaque(false);

        try {
            Font theLastOfUsFont = Font.createFont(Font.TRUETYPE_FONT, new File("font.ttf"));
            Font buttonFont = theLastOfUsFont.deriveFont(50f);
            startButton.setFont(buttonFont);
        } catch (IOException | FontFormatException ex) {
            ex.printStackTrace();
        }
        setResizable(false);
        startButton.setFocusPainted(false);
        startButton.setBorder(null);
        startButton.setUI(new BasicButtonUI());

        startButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    Game.loadHeroes("Heroes.csv");
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
                getContentPane().remove(startButton);
                getContentPane().add(createHeroSelectionPanel(), BorderLayout.CENTER);

                revalidate();
                repaint();
            }
        });

        startButton.setForeground(Color.WHITE);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.setOpaque(false);
        buttonPanel.add(startButton);
        getContentPane().add(buttonPanel, BorderLayout.NORTH);

        revalidate();
        repaint();
    }

    public JPanel createHeroSelectionPanel() {
        JPanel heroSelectionPanel = new JPanel();
        heroSelectionPanel.setLayout(new GridLayout(4, 2, 10, 10));

        ArrayList<Hero> heroList = Game.availableHeroes;

        try {
            Font theLastOfUsFont = Font.createFont(Font.TRUETYPE_FONT, new File("font.ttf"));
            Font buttonFont = theLastOfUsFont.deriveFont(30f);

            for (int i = 0; i < heroList.size(); i++) {
                Hero hero = heroList.get(i);
                String n;
                String name = hero.getName();

                if (hero.getName().equals("Joel Miller") || hero.getName().equals("David"))
                    n = "Fighter";
                else if (hero.getName().equals("Ellie Williams") || hero.getName().equals("Bill"))
                    n = "Medic";
                else
                    n = "Explorer";

                JButton heroButton = new JButton(hero.getName()) {
                    @Override
                    protected void paintComponent(Graphics g) {
                        ImageIcon backgroundImage = null;
                        if (name.equals("Joel Miller")) {
                            backgroundImage = new ImageIcon("j.jpg");
                        } else if (name.equals("Ellie Williams")) {
                            backgroundImage = new ImageIcon("e.jpg");
                        } else if (name.equals("Tess")) {
                            backgroundImage = new ImageIcon("t.jpg");
                        } else if (name.equals("Tommy Miller")) {
                            backgroundImage = new ImageIcon("tm.jpg");
                        } else if (name.equals("Bill")) {
                            backgroundImage = new ImageIcon("b.jpg");
                        } else if (name.equals("David")) {
                            backgroundImage = new ImageIcon("d.png");
                        } else if (name.equals("Henry Burell")) {
                            backgroundImage = new ImageIcon("h.jpg");
                        } else if (name.equals("Riley Abel")) {
                            backgroundImage = new ImageIcon("r.png");
                        } else {
                            backgroundImage = new ImageIcon("a.jpg");
                        }

                        Image image = backgroundImage.getImage();
                        g.drawImage(image, 0, 0, getWidth(), getHeight(), this);

                        super.paintComponent(g);
                    }
                };

                heroButton.setContentAreaFilled(false);
                heroButton.setFont(buttonFont);
                heroButton.setForeground(Color.WHITE);
                heroButton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        String heroAttributes = "Type: " + n + "\n" +
                                "Name: " + hero.getName() + "\n" +
                                "Max HP: " + hero.getMaxHp() + "\n" +
                                "Attack Damage: " + hero.getAttackDmg() + "\n" +
                                "Max Actions: " + hero.getMaxActions();

                        CustomDialog dialog = new CustomDialog(HeroSelectionFrame.this, heroAttributes, "Hero Details", hero, HeroSelectionFrame.this);                   
                        dialog.setVisible(true);
                    }
                });

                heroSelectionPanel.add(heroButton);
            }
        } catch (IOException | FontFormatException ex) {
            ex.printStackTrace();
        }

        heroSelectionPanel.setBackground(new Color(0, 0, 0));
        return heroSelectionPanel;
    }

    public void onHeroSelected(String sharedConstant, GameGUI gj) {
        if (sharedConstant.equals("HERO_SELECTION_COMPLETE")) {
            mediaPlayer.stop();
            dispose(); 

            SwingUtilities.invokeLater(new Runnable() {
                public void run() {
                    gj.showReadyDialog();
                    
                }
            });
        }
    }

   

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                HeroSelectionFrame frame = new HeroSelectionFrame();
                frame.setVisible(true);
                frame.mediaPlayer.play();

                
                frame.setTitle("TLoU:Legacy");

                
                Image logo = Toolkit.getDefaultToolkit().getImage("logo.png");
                frame.setIconImage(logo);
            }
        });
    }

}
