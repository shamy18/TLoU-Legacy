package model.characters;

import java.awt.Point;

import model.world.Cell;
import model.world.CharacterCell;
import engine.Game;
import exceptions.InvalidTargetException;
import exceptions.NoAvailableResourcesException;
import exceptions.NotEnoughActionsException;

public abstract class Character {

	private String name;
	private int maxHp;
	private int currentHp;
	private Point location;
	private int attackDmg;
	private Character target;

	public Character(String name, int maxHp, int attackDamage) {
		this.name = name;
		this.maxHp = maxHp;
		this.attackDmg = attackDamage;
		this.currentHp = maxHp;
	}

	public int getCurrentHp() {
		return currentHp;
	}

	public void setCurrentHp(int currentHp) {
		if (currentHp <= 0) {
			this.currentHp = 0;
			onCharacterDeath();
			
		} else if (currentHp > maxHp) {
			this.currentHp = maxHp;
		} else
			this.currentHp = currentHp;
	}

	public Point getLocation() {
		return location;
	}

	public void setLocation(Point location) {
		this.location = location;
	}

	public Character getTarget() {
		return target;
	}

	public void setTarget(Character target) {
		this.target = target;
	}

	public String getName() {
		return name;
	}

	public int getMaxHp() {
		return maxHp;
	}

	public int getAttackDmg() {
		return attackDmg;
	}

	public void attack() throws NotEnoughActionsException,
			InvalidTargetException {
		getTarget().setCurrentHp(getTarget().getCurrentHp() - getAttackDmg());
		getTarget().defend(this);
		if(this.getTarget().currentHp==0) {
			this.setTarget(null);
			if(this instanceof Explorer && ((Hero)this).isSpecialAction()) {
				for(int i = 0; i < Game.map.length; i++) {
					for(int j = 0; j < Game.map[i].length; j++) {
						Game.map[i][j].setVisible(true);
					}
				}
			}
				
		}
			
		
	}

	public void defend(Character c) {
		c.setCurrentHp(c.getCurrentHp() - getAttackDmg() / 2);
	}

	public void onCharacterDeath() {
		Point p = this.getLocation();
		int f=0;
		if (this instanceof Zombie) {
			Game.zombies.remove(this);
			
			for(int i=0;i<Game.heroes.size();i++) {
				Hero h= Game.heroes.get(i);
				if(h.getName().equals("Tess") || h.getName().equals("Riley Abel") || h.getName().equals("Tommy Miller"))
					if(h.isSpecialAction())
						f=1;
			}
				
				
			if(f==0)		
				Game.spawnNewZombie();
			if(f==1)
				Game.spawnNewZombie2();
				
		} else if (this instanceof Hero) {
			Game.heroes.remove(this);
		}
		((CharacterCell)Game.map[p.x][p.y]).setCharacter(null);
		Game.map[p.x][p.y].setVisible(true);
	}

}
