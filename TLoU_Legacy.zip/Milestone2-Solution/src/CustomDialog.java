import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import engine.Game;
import exceptions.InvalidTargetException;
import exceptions.NoAvailableResourcesException;
import model.characters.Hero;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.StackPane;
import java.io.IOException;
import java.util.concurrent.atomic.AtomicInteger;

import javafx.application.Platform;
import javafx.embed.swing.JFXPanel;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import javafx.application.Platform;
import javafx.embed.swing.JFXPanel;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import java.awt.Graphics;
import java.io.File;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class CustomDialog extends JDialog {
    private java.awt.Image backgroundImage;
    private Hero hero;
    private JFrame parentFrame;
    private String sharedConstant;
    private GameGUI g;
    private Clip audioClip;
    private MediaPlayer mediaPlayer;
    private HeroSelectionListener listener;
    public static int defaultOption;

    public int getDefaultOption() {
        return defaultOption;
    }
    
    public CustomDialog(JFrame parent, String heroAttributes, String title, String s, AtomicInteger defaultOption) {
        super(parent, title, true);
        setUndecorated(true);
        setBackground(new Color(0, 0, 0, 0));

        
        backgroundImage = new ImageIcon("dialog_background.jpg").getImage();

        
        JLabel attributesLabel = new JLabel("<html><pre>" + heroAttributes + "</pre></html>");
        attributesLabel.setForeground(Color.WHITE);
        attributesLabel.setFont(new Font("Arial", Font.PLAIN, 16));

        
        JButton healButton = new JButton("Heal");
        healButton.setFont(new Font("font.ttf", Font.PLAIN, 16));

        
        healButton.setOpaque(false);
        healButton.setContentAreaFilled(false);
        healButton.setBorderPainted(false);

        
        healButton.setForeground(Color.WHITE);

        
        healButton.setFocusPainted(false);
        
        Border border = BorderFactory.createLineBorder(Color.WHITE);
        Border margin = new EmptyBorder(5, 15, 5, 15);
        Border compoundBorder = BorderFactory.createCompoundBorder(border, margin);
        healButton.setBorder(compoundBorder);



        healButton.addActionListener(new ActionListener() {
            

			

			@Override
            public void actionPerformed(ActionEvent e) {
                defaultOption.set(0);
                dispose();
                
            }
        });



        JButton backButton = new JButton("Back");
        backButton.setFont(new Font("font.ttf", Font.PLAIN, 16)); 


        backButton.setOpaque(false);
        backButton.setContentAreaFilled(false);
        backButton.setBorderPainted(false);



        backButton.setForeground(Color.WHITE);

        
        backButton.setFocusPainted(false);

       
        backButton.setBorder(compoundBorder);

       
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	defaultOption.set(1);
            	dispose();
            }
        });

        JPanel contentPanel = new JPanel(new BorderLayout(10, 10));
        contentPanel.setBackground(new Color(0, 0, 0, 200));
        contentPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        contentPanel.add(attributesLabel, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        buttonPanel.setOpaque(false);
        buttonPanel.add(healButton);
        buttonPanel.add(backButton);
        contentPanel.add(buttonPanel, BorderLayout.SOUTH);

        setLayout(new BorderLayout());
        add(contentPanel, BorderLayout.CENTER);

        pack();

        setLocationRelativeTo(parent);
    }

    
    public CustomDialog(JFrame parent, String message, String title) {
        super(parent, title, true);
        setUndecorated(true);
        setBackground(new Color(0, 0, 0, 0));

        backgroundImage = new ImageIcon("dialog_background.jpg").getImage();

        JLabel messageLabel = new JLabel("<html><pre>" + message + "</pre></html>");
        messageLabel.setForeground(Color.WHITE);
        messageLabel.setFont(new Font("Arial", Font.PLAIN, 16));

        JButton okButton = new JButton("YES");
        okButton.setFont(new Font("font.ttf", Font.PLAIN, 16)); 

        okButton.setOpaque(false);
        okButton.setContentAreaFilled(false);
        okButton.setBorderPainted(false);

        okButton.setForeground(Color.WHITE);

        okButton.setFocusPainted(false);

        Border border = BorderFactory.createLineBorder(Color.WHITE);
        Border margin = new EmptyBorder(5, 15, 5, 15);
        Border compoundBorder = BorderFactory.createCompoundBorder(border, margin);
        okButton.setBorder(compoundBorder);

        okButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GameGUI.setIcons();
                GameGUI.setVisibility();
                dispose();
            }
        });

        JPanel contentPanel = new JPanel(new BorderLayout(10, 10));
        contentPanel.setBackground(new Color(0, 0, 0, 200));
        contentPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        contentPanel.add(messageLabel, BorderLayout.CENTER);
        contentPanel.add(okButton, BorderLayout.SOUTH);

        setLayout(new BorderLayout());
        add(contentPanel, BorderLayout.CENTER);

        pack();

        setLocationRelativeTo(parent);
    }
    
    public CustomDialog(JFrame parent, String message, String title, int x) {
        super(parent, title, true);
        setUndecorated(true);
        setBackground(new Color(0, 0, 0, 0));

        backgroundImage = new ImageIcon("dialog_background.jpg").getImage();

        JLabel messageLabel = new JLabel("<html><pre>" + message + "</pre></html>");
        messageLabel.setForeground(Color.WHITE);
        messageLabel.setFont(new Font("Arial", Font.PLAIN, 16));

        JButton okButton = new JButton("OK");
        okButton.setFont(new Font("font.ttf", Font.PLAIN, 16)); 

        okButton.setOpaque(false);
        okButton.setContentAreaFilled(false);
        okButton.setBorderPainted(false);

        okButton.setForeground(Color.WHITE);

        okButton.setFocusPainted(false);

        Border border = BorderFactory.createLineBorder(Color.WHITE);
        Border margin = new EmptyBorder(5, 15, 5, 15);
        Border compoundBorder = BorderFactory.createCompoundBorder(border, margin);
        okButton.setBorder(compoundBorder);

        okButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GameGUI.setIcons();
                GameGUI.setVisibility();
                dispose();
            }
        });

        JPanel contentPanel = new JPanel(new BorderLayout(10, 10));
        contentPanel.setBackground(new Color(0, 0, 0, 200));
        contentPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        contentPanel.add(messageLabel, BorderLayout.CENTER);
        contentPanel.add(okButton, BorderLayout.SOUTH);

        setLayout(new BorderLayout());
        add(contentPanel, BorderLayout.CENTER);

        pack();

        setLocationRelativeTo(parent);
    }
    

    public CustomDialog(HeroSelectionFrame parent, String message, String title, Hero hero, HeroSelectionListener listener) {
        super(parent, title, true);
        this.listener = listener;
        this.sharedConstant = sharedConstant;
        this.parentFrame = parent;
        this.hero = hero;
        setUndecorated(true); 
        setBackground(new Color(0, 0, 0, 0)); 

        backgroundImage = new ImageIcon("dialog_background.jpg").getImage();

        JLabel messageLabel = new JLabel("<html><pre>" + message + "</pre></html>");
        messageLabel.setForeground(Color.WHITE);
        messageLabel.setFont(new Font("Arial", Font.PLAIN, 16));

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        buttonPanel.setOpaque(false); 

        JButton selectButton = new JButton("Select");
        selectButton.setFont(new Font("font.ttf", Font.PLAIN, 16)); 

        selectButton.setOpaque(false);
        selectButton.setContentAreaFilled(false);
        selectButton.setBorderPainted(false);

        selectButton.setForeground(Color.WHITE);

        selectButton.setFocusPainted(false);

        Border selectBorder = BorderFactory.createLineBorder(Color.WHITE);
        Border selectMargin = new EmptyBorder(5, 15, 5, 15);
        Border selectCompoundBorder = BorderFactory.createCompoundBorder(selectBorder, selectMargin);
        selectButton.setBorder(selectCompoundBorder);

        selectButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Game.startGame(hero);
                GameGUI gameGUI = null;

                try {
                    gameGUI = new GameGUI();
                   
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
                sharedConstant = "HERO_SELECTION_COMPLETE";
                if (parent != null) {
                	listener.onHeroSelected(sharedConstant, gameGUI);
                }
                
                dispose();
                //gameGUI.startframe();
            }
        });

        buttonPanel.add(selectButton);

        JButton backButton = new JButton("Back");
        backButton.setFont(new Font("font.ttf", Font.PLAIN, 16)); 

        
        backButton.setOpaque(false);
        backButton.setContentAreaFilled(false);
        backButton.setBorderPainted(false);

        backButton.setForeground(Color.WHITE);

        Border backBorder = BorderFactory.createLineBorder(Color.WHITE);
        Border backMargin = new EmptyBorder(5, 15, 5, 15);
        Border backCompoundBorder = BorderFactory.createCompoundBorder(backBorder, backMargin);
        backButton.setBorder(backCompoundBorder);

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });

        buttonPanel.add(backButton);

       
        JPanel contentPanel = new JPanel(new BorderLayout(10, 10));
        contentPanel.setBackground(new Color(0, 0, 0, 200)); 
        contentPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        contentPanel.add(messageLabel, BorderLayout.CENTER);
        contentPanel.add(buttonPanel, BorderLayout.SOUTH);

        setLayout(new BorderLayout());
        add(contentPanel, BorderLayout.CENTER);

        pack();

        setLocationRelativeTo(parentFrame);
    }
    public CustomDialog(JFrame parent, String message, String title, GameGUI ui) {
        super(parent, title, true);
        setUndecorated(true);
        setBackground(new Color(0, 0, 0, 0));

       
        backgroundImage = new ImageIcon("dialog_background.jpg").getImage();

       
        JLabel messageLabel = new JLabel("<html><pre>" + message + "</pre></html>");
        messageLabel.setForeground(Color.WHITE);
        messageLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        messageLabel.setHorizontalAlignment(SwingConstants.CENTER);

       
        JButton closeButton = new JButton("Close");
        closeButton.setFont(new Font("font.ttf", Font.PLAIN, 16)); 

      
        closeButton.setForeground(Color.WHITE);

       
        closeButton.setOpaque(false);
        closeButton.setContentAreaFilled(false);
        closeButton.setBorderPainted(false);

      
        closeButton.setFocusPainted(false);

       
        closeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        
        JButton playAgainButton = new JButton("Play Again");
        playAgainButton.setFont(new Font("font.ttf", Font.PLAIN, 16)); 

        
        playAgainButton.setForeground(Color.WHITE);

      
        playAgainButton.setOpaque(false);
        playAgainButton.setContentAreaFilled(false);
        playAgainButton.setBorderPainted(false);

       
        playAgainButton.setFocusPainted(false);

      

        JPanel contentPanel = new JPanel(new BorderLayout());
        contentPanel.setBackground(new Color(0, 0, 0, 200));
        contentPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        contentPanel.add(messageLabel, BorderLayout.CENTER);

        
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.setOpaque(false);
        buttonPanel.add(playAgainButton);
        buttonPanel.add(closeButton);

       
        contentPanel.add(buttonPanel, BorderLayout.SOUTH);

      
        setLayout(new BorderLayout());
        add(contentPanel, BorderLayout.CENTER);

     
        pack();
        setSize(960, 540);

       
        setLocationRelativeTo(parent);

        Platform.runLater(() -> {
            JFXPanel jfxPanel = new JFXPanel();

            String videoPath = "youwin2.mp4";
            Media videoMedia = new Media(new File(videoPath).toURI().toString());
            MediaPlayer videoPlayer = new MediaPlayer(videoMedia);
            videoPlayer.setAutoPlay(true);
            videoPlayer.setCycleCount(MediaPlayer.INDEFINITE);

            MediaView mediaView = new MediaView(videoPlayer);
            mediaView.setPreserveRatio(false);
            mediaView.setFitWidth(getWidth());
            mediaView.setFitHeight(getHeight());

            Group root = new Group();
            root.getChildren().add(mediaView);

            Scene scene = new Scene(root, getWidth(), getHeight());

            jfxPanel.setScene(scene);
            add(jfxPanel, BorderLayout.CENTER);

            videoPlayer.play();

            addWindowListener(new java.awt.event.WindowAdapter() {
                @Override
                public void windowClosing(java.awt.event.WindowEvent windowEvent) {
                    Platform.runLater(() -> {
                        videoPlayer.stop();
                        Platform.exit();
                    });
                }
            });
        });
        
        playAgainButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	
            	HeroSelectionFrame h=new HeroSelectionFrame();
                h.setVisible(true);
                HeroSelectionFrame.main(null);
            	mediaPlayer.stop();
                
                dispose();
                parent.dispose();
                
            }
        });
    }
    
    
    public CustomDialog(JFrame parent, String message, String title, GameGUI ui, GameGUI gjj) {
        super(parent, title, true);
        setUndecorated(true);
        setBackground(new Color(0, 0, 0, 0));

        ImageIcon backgroundImage = new ImageIcon("dialog_background.jpg");

        JLabel messageLabel = new JLabel("<html><pre>" + message + "</pre></html>");
        messageLabel.setForeground(Color.WHITE);
        messageLabel.setFont(new Font("Arial", Font.PLAIN, 16));

        JButton playAgainButton = new JButton("Play Again");
        playAgainButton.setFont(new Font("font.ttf", Font.PLAIN, 16)); 

        playAgainButton.setForeground(Color.WHITE);

        playAgainButton.setOpaque(false);
        playAgainButton.setContentAreaFilled(false);
        playAgainButton.setBorderPainted(false);

        playAgainButton.setFocusPainted(false);

        JButton closeButton = new JButton("Close");
        closeButton.setFont(new Font("font.ttf", Font.PLAIN, 16)); 

        closeButton.setForeground(Color.WHITE);

        closeButton.setOpaque(false);
        closeButton.setContentAreaFilled(false);
        closeButton.setBorderPainted(false);

        closeButton.setFocusPainted(false);

        JFXPanel videoPanel = new JFXPanel();

        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.setOpaque(false);
        buttonPanel.add(playAgainButton);
        buttonPanel.add(closeButton);

        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(videoPanel, BorderLayout.CENTER);
        getContentPane().add(buttonPanel, BorderLayout.SOUTH);

        setSize(498, 498);

        setLocationRelativeTo(parent);

        Platform.runLater(() -> {
            String songFile = "youlose.mp3";
            Media media = new Media(new File(songFile).toURI().toString());
            mediaPlayer = new MediaPlayer(media);
            mediaPlayer.setCycleCount(MediaPlayer.INDEFINITE);
            mediaPlayer.setAutoPlay(true);

            String videoFile = "gipp.mp4";
            Media videoMedia = new Media(new File(videoFile).toURI().toString());
            MediaPlayer videoPlayer = new MediaPlayer(videoMedia);
            videoPlayer.setCycleCount(MediaPlayer.INDEFINITE);
            videoPlayer.setAutoPlay(true);

            MediaView mediaView = new MediaView(videoPlayer);
            StackPane videoPane = new StackPane(mediaView);

            BorderPane root = new BorderPane(videoPane);
            Scene scene = new Scene(root, 498, 498);
            videoPanel.setScene(scene);

            videoPlayer.setOnReady(() -> {
                videoPlayer.play();
                mediaPlayer.setVolume(0.5); 
            });

            playAgainButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                   
                	HeroSelectionFrame h=new HeroSelectionFrame();
                	HeroSelectionFrame.main(null);
                    h.setVisible(true);
                	mediaPlayer.stop();
                    videoPlayer.stop();
                    dispose();
                    ui.dispose();
                    
                }
            });

            closeButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                	System.exit(0);
                	mediaPlayer.stop();
                    videoPlayer.stop();
                    
                    
                }
            });
        });
    }

    public void showDialog() {
        setVisible(true);
    }


    @Override
    public void paint(Graphics g) {
        super.paint(g);

        g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
    }
}
