import java.awt.*;
import java.io.File;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicInteger;

import javafx.application.Application;
import javafx.embed.swing.JFXPanel;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineEvent;
import javax.sound.sampled.LineListener;
import javax.swing.*;
import engine.Game;
import exceptions.InvalidTargetException;
import exceptions.MovementException;
import exceptions.NoAvailableResourcesException;
import exceptions.NotEnoughActionsException;
import model.characters.*;
import model.characters.Character;
import model.collectibles.Collectible;
import model.collectibles.Supply;
import model.collectibles.Vaccine;
import model.world.*;
import model.characters.*;
import javafx.application.Platform;
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.embed.swing.JFXPanel;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;

public class GameGUI extends JFrame {
    private static Character target=null;
    private static Character zombietarget=null;
    private static Character targettoheal=null;
	private static  JPanel gamePanel;
    private JPanel actionsPanel;
    private JPanel upperPanel;
    private static ImagePanel lowerPanel;
    private JButton up;
    private JButton down;
    private JButton left;
    private JButton right;
    private JButton attack;
    private JButton cure;
    private JButton special;
    private JButton endturn;
    private static int f=0;
    private static int count=0;
    private static int x; 
    private static int y; 
    private static int COLOR_CHANGE_DELAY = 200;
    private boolean setheal=false;
    private static boolean alternate=false;
   static int clicked=0;
    static int br=0;
    static int et=0;
   static HeroSelectionFrame hsf;
   static GameGUI gameGUI=null;
   static MediaPlayer mediaPlayer;

    public GameGUI() throws IOException {
        super("Game GUI");
        new JFXPanel();
        
        
        //Game.startGame(new Medic("Balls", 1, 120, 500));
        //Explorer e=new Explorer("Tess", 1, 232, 500);
       // e.setLocation(new Point(0,1));
        //((CharacterCell)Game.map[0][1]).setCharacter(e);
        //Game.heroes.add(e);
        //Game.adjustVisibility(e);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1280, 720);
        gameGUI=this;
        gamePanel = new JPanel(new GridLayout(15, 15));
        actionsPanel = new JPanel(new BorderLayout());
        upperPanel = new ImagePanel("bg2.jpg");
        upperPanel.setLayout(new GridBagLayout());
        lowerPanel = new ImagePanel("bg3.jpg");
        lowerPanel.setLayout(new GridLayout(6, 1)); 
        actionsPanel.add(lowerPanel, BorderLayout.SOUTH);

        for (int row = 0; row < 15; row++) {
            for (int col = 0; col < 15; col++) {
                BackgroundImageButton cellButton = new BackgroundImageButton("tile.jpg");
                cellButton.setPreferredSize(new Dimension(50, 50));
                gamePanel.add(cellButton);

                final int buttonX = row;
                final int buttonY = col;

                cellButton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        x = buttonX;
                        y = buttonY;
                        clicked = 1;
                        
                        if (et == 0) {
                            displayCharacterAttributes(x, y);
                            setZombieTarget(x, y);
                            setIcons(); 
                            setVisibility(); 
                            refreshAttributesPanel(x, y);
                            if (setheal) {
                                if (Game.map[x][y] instanceof CharacterCell && target instanceof Medic)
                                    targettoheal = ((CharacterCell) Game.map[x][y]).getCharacter();
                                setheal = false;
                            }
                            
                        }
                    }
                });
            }
        }
        String musicFile = "bgm.mp3";
        Media sound = new Media(new File(musicFile).toURI().toString());

      
        GameGUI.mediaPlayer = new MediaPlayer(sound);
        GameGUI.mediaPlayer.setCycleCount(MediaPlayer.INDEFINITE);

        GameGUI.mediaPlayer.play();
        
        

        
    
        up = new JButton("UP");
        down = new JButton("DOWN");
        left = new JButton("LEFT");
        right = new JButton("RIGHT");
        attack = new JButton("ATTACK");
        cure = new JButton("CURE");
        special = new JButton("SPECIAL");
        endturn = new JButton("END TURN");

      
        attack.setBackground(Color.RED);
        cure.setBackground(Color.GREEN);
        special.setBackground(Color.YELLOW);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5); 

        
        gbc.gridx = 0;
        gbc.gridy = 0;
        upperPanel.add(up, gbc);

        gbc.gridx = 1;
        gbc.gridy = 0;
        upperPanel.add(down, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        upperPanel.add(attack, gbc);

        gbc.gridx = 1;
        gbc.gridy = 1;
        upperPanel.add(cure, gbc);

        gbc.gridx = 2;
        gbc.gridy = 0;
        upperPanel.add(left, gbc);

        gbc.gridx = 3;
        gbc.gridy = 0;
        upperPanel.add(right, gbc);

        gbc.gridx = 2;
        gbc.gridy = 1;
        upperPanel.add(special, gbc);

        gbc.gridx = 3;
        gbc.gridy = 1;
        upperPanel.add(endturn, gbc);

        actionsPanel.add(upperPanel, BorderLayout.NORTH);
        actionsPanel.add(lowerPanel, BorderLayout.CENTER);

        setLayout(new BorderLayout());
        add(gamePanel, BorderLayout.WEST);
        add(actionsPanel, BorderLayout.CENTER);

        setVisible(true);
        up.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
               if(et==0) {
            	try {
            		if(target==null) {
            			CustomDialog d= new CustomDialog(GameGUI.this,  "Select Hero to move","InvalidTargetException",0);
            			d.setVisible(true);
            			
            		}
                		
                    if (target instanceof Fighter)
                        ((Fighter) target).move(Direction.DOWN);
                    else if (target instanceof Medic)
                        ((Medic) target).move(Direction.DOWN);
                    else if (target instanceof Explorer)
                        ((Explorer) target).move(Direction.DOWN);
                } catch (MovementException ex) {
                	CustomDialog d= new CustomDialog(GameGUI.this, "Can't move there!", "Movement Exception",0);
        			d.setVisible(true);
        			
                } catch (NotEnoughActionsException ex) {
                	CustomDialog d= new CustomDialog(GameGUI.this, "Not enough actions!", "Not Enough Actions",0);
        			d.setVisible(true);
                }
                setIcons(); 
                setVisibility(); 
                if(target.getCurrentHp()==0)
                	heroDeath(target, GameGUI.this);
                refreshAttributesPanel(x,y);
            }
            }
        });

        down.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	 if(et==0) {
            	try {
            		if(target==null) {
            			CustomDialog d= new CustomDialog(GameGUI.this,  "Select Hero to move","InvalidTargetException",0);
            			d.setVisible(true);
            			
            		}
                    if (target instanceof Fighter)
                        ((Fighter) target).move(Direction.UP);
                    else if (target instanceof Medic)
                        ((Medic) target).move(Direction.UP);
                    else if (target instanceof Explorer)
                        ((Explorer) target).move(Direction.UP);
                } catch (MovementException ex) {
                	CustomDialog d= new CustomDialog(GameGUI.this, "Can't move there!", "Movement Exception",0);
        			d.setVisible(true);
        			
                } catch (NotEnoughActionsException ex) {
                	CustomDialog d= new CustomDialog(GameGUI.this, "Not enough actions!", "Not Enough Actions",0);
        			d.setVisible(true);
                }
                setIcons(); 
                setVisibility();
                if(target.getCurrentHp()==0)
                	heroDeath(target, GameGUI.this);
                refreshAttributesPanel(x,y);
            	 }
            }
        });

        left.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	 if(et==0) {
            	try {
            		if(target==null) {
            			CustomDialog d= new CustomDialog(GameGUI.this,  "Select Hero to move","InvalidTargetException",0);
            			d.setVisible(true);
            			
            		}
                    if (target instanceof Fighter)
                        ((Fighter) target).move(Direction.LEFT);
                    else if (target instanceof Medic)
                        ((Medic) target).move(Direction.LEFT);
                    else if (target instanceof Explorer)
                        ((Explorer) target).move(Direction.LEFT);
                } catch (MovementException ex) {
                	CustomDialog d= new CustomDialog(GameGUI.this, "Can't move there!", "Movement Exception",0);
        			d.setVisible(true);
        			
                } catch (NotEnoughActionsException ex) {
                	CustomDialog d= new CustomDialog(GameGUI.this, "Not enough actions!", "Not Enough Actions",0);
        			d.setVisible(true);
                }
                setIcons();
                setVisibility();
                if(target.getCurrentHp()==0)
                	heroDeath(target,GameGUI.this);
                refreshAttributesPanel(x,y);
            	 }
            }
        });

   

     

        right.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	 if(et==0) {
            	try {
            		if(target==null) {
            			CustomDialog d= new CustomDialog(GameGUI.this,  "Select Hero to move","InvalidTargetException",0);
            			d.setVisible(true);
            			
            		}
                	if (target instanceof Fighter)
                        ((Fighter) target).move(Direction.RIGHT);
                    else if (target instanceof Medic)
                        ((Medic) target).move(Direction.RIGHT);
                    else if (target instanceof Explorer)
                        ((Explorer) target).move(Direction.RIGHT);
                } catch (MovementException ex) {
                	CustomDialog d= new CustomDialog(GameGUI.this, "Can't move there!", "Movement Exception",0);
        			d.setVisible(true);
        			
                } catch (NotEnoughActionsException ex) {
                	CustomDialog d= new CustomDialog(GameGUI.this, "Not enough actions!", "Not Enough Actions",0);
        			d.setVisible(true);
                }
                setIcons(); 
                setVisibility();
                if(target.getCurrentHp()==0)
                	heroDeath(target, GameGUI.this);
                refreshAttributesPanel(x,y);
            	 }
            }
        });

        
    
        InputMap inputMap = gamePanel.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
        ActionMap actionMap = gamePanel.getActionMap();

       
        inputMap.put(KeyStroke.getKeyStroke(KeyEvent.VK_UP, 0), "moveUp");
        actionMap.put("moveUp", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	 if(et==0) {
            	try {
            		if(target==null) {
            			CustomDialog d= new CustomDialog(GameGUI.this,  "Select Hero to move","InvalidTargetException",0);
            			d.setVisible(true);
            			
            		}
                    if (target instanceof Fighter)
                        ((Fighter) target).move(Direction.DOWN);
                    else if (target instanceof Medic)
                        ((Medic) target).move(Direction.DOWN);
                    else if (target instanceof Explorer)
                        ((Explorer) target).move(Direction.DOWN);
                } catch (MovementException ex) {
                	CustomDialog d= new CustomDialog(GameGUI.this, "Can't move there!", "Movement Exception",0);
        			d.setVisible(true);
        			
                } catch (NotEnoughActionsException ex) {
                	CustomDialog d= new CustomDialog(GameGUI.this, "Not enough actions!", "Not Enough Actions",0);
        			d.setVisible(true);
                }
                setIcons(); 
                setVisibility();
                if(target.getCurrentHp()==0)
                	heroDeath(target, GameGUI.this);
                refreshAttributesPanel(x, y); 
            	 }
            }
        });

        
        inputMap.put(KeyStroke.getKeyStroke(KeyEvent.VK_DOWN, 0), "moveDown");
        actionMap.put("moveDown", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	 if(et==0) {
            	try {
            		if(target==null) {
            			CustomDialog d= new CustomDialog(GameGUI.this,  "Select Hero to move","InvalidTargetException",0);
            			d.setVisible(true);
            			
            		}
                    if (target instanceof Fighter)
                        ((Fighter) target).move(Direction.UP);
                    else if (target instanceof Medic)
                        ((Medic) target).move(Direction.UP);
                    else if (target instanceof Explorer)
                        ((Explorer) target).move(Direction.UP);
                } catch (MovementException ex) {
                	CustomDialog d= new CustomDialog(GameGUI.this, "Can't move there!", "Movement Exception",0);
        			d.setVisible(true);
        			
                } catch (NotEnoughActionsException ex) {
                	CustomDialog d= new CustomDialog(GameGUI.this, "Not enough actions!", "Not Enough Actions",0);
        			d.setVisible(true);
                }
                setIcons(); 
                setVisibility();
                if(target.getCurrentHp()==0)
                	heroDeath(target, GameGUI.this);
                refreshAttributesPanel(x, y); 
            	 }
            }
        });

        
        inputMap.put(KeyStroke.getKeyStroke(KeyEvent.VK_LEFT, 0), "moveLeft");
        actionMap.put("moveLeft", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	 if(et==0) {
            	try {
            		if(target==null) {
            			CustomDialog d= new CustomDialog(GameGUI.this,  "Select Hero to move","InvalidTargetException",0);
            			d.setVisible(true);
            			
            		}
                    if (target instanceof Fighter)
                        ((Fighter) target).move(Direction.LEFT);
                    else if (target instanceof Medic)
                        ((Medic) target).move(Direction.LEFT);
                    else if (target instanceof Explorer)
                        ((Explorer) target).move(Direction.LEFT);
                } catch (MovementException ex) {
                	CustomDialog d= new CustomDialog(GameGUI.this, "Can't move there!", "Movement Exception",0);
        			d.setVisible(true);
        			
                } catch (NotEnoughActionsException ex) {
                	CustomDialog d= new CustomDialog(GameGUI.this, "Not enough actions!", "Not Enough Actions",0);
        			d.setVisible(true);
                }
                setIcons(); 
                setVisibility();
                if(target.getCurrentHp()==0)
                	heroDeath(target, GameGUI.this);
                refreshAttributesPanel(x, y); 
            	 }
            }
        });

        
        inputMap.put(KeyStroke.getKeyStroke(KeyEvent.VK_RIGHT, 0), "moveRight");
        actionMap.put("moveRight", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	 if(et==0) {
            	try {
            		if(target==null) {
            			CustomDialog d= new CustomDialog(GameGUI.this,  "Select Hero to move","InvalidTargetException",0);
            			d.setVisible(true);
            			
            		}

                    if (target instanceof Fighter)
                        ((Fighter) target).move(Direction.RIGHT);
                    else if (target instanceof Medic)
                        ((Medic) target).move(Direction.RIGHT);
                    else if (target instanceof Explorer)
                        ((Explorer) target).move(Direction.RIGHT);
                } catch (MovementException ex) {
                	CustomDialog d= new CustomDialog(GameGUI.this, "Can't move there!", "Movement Exception",0);
        			d.setVisible(true);
        			
                } catch (NotEnoughActionsException ex) {
                	CustomDialog d= new CustomDialog(GameGUI.this, "Not enough actions!", "Not Enough Actions",0);
        			d.setVisible(true);
                }
                setIcons();
                setVisibility();
                if(target.getCurrentHp()==0)
                	heroDeath(target, GameGUI.this);
                refreshAttributesPanel(x, y); 
            	 }
            }
        });

 
 special.addActionListener(new ActionListener() {
	    public void actionPerformed(ActionEvent e) {
	    	 if(et==0) {
	    		 if(target==null) {
         			CustomDialog d= new CustomDialog(GameGUI.this,  "Select Hero to use special","InvalidTargetException",0);
         			d.setVisible(true);
         			
         		} else {
	        	setheal=true;
	            try {
	                if (target instanceof Fighter) {
	                    ((Fighter)target).useSpecial();
	                } else if (target instanceof Medic) {
	                	setheal = true;
	                	CustomDialog d= new CustomDialog(GameGUI.this,  "Select Hero to heal","Choose",0);
	         			d.setVisible(true);
	                	createHeroHealSelectionFrame();
	                	
	                }  else if (target instanceof Explorer) {
	                    ((Explorer) target).useSpecial();
	                } else if (((Hero) target).isSpecialAction() && !(target instanceof Medic)) {
	                	CustomDialog d= new CustomDialog(GameGUI.this,  "Selected Hero's special has been used this turn","Error",0);
	         			d.setVisible(true);
	                }
	                setheal = false;
	                
	            } catch (NoAvailableResourcesException e1) {
	            	CustomDialog d= new CustomDialog(GameGUI.this,  "No supplies in inventory","error",0);
         			d.setVisible(true);
	            } catch (InvalidTargetException e2) {
	            	CustomDialog d= new CustomDialog(GameGUI.this,  "Select Hero to heal","Choose",0);
         			d.setVisible(true);
	            }
	        }
	        setIcons(); 
	        setVisibility(); 
	        refreshAttributesPanel(x,y);
	    	 }
	    }
	});
 
 

 attack.addActionListener(new ActionListener() {
	    public void actionPerformed(ActionEvent e) {
	    	 if(et==0) {
	    	if (target == null) {
	    		CustomDialog d= new CustomDialog(GameGUI.this,  "Select Hero that will attack","Error",0);
     			d.setVisible(true);
	        } 
	        else if(target.getTarget()==null) {
	        	CustomDialog d= new CustomDialog(GameGUI.this,  "No zombie selected to attack","Error",0);
 				d.setVisible(true);
 				}
	        
	        
	        else {
	        	int c2=0;
	        	try {
					target.attack();
					
				} catch (NotEnoughActionsException e1) {
					 c2=1;
					 CustomDialog d= new CustomDialog(GameGUI.this,  "No action points left","Error",0);
		 				d.setVisible(true);
				} catch (InvalidTargetException e1) {
					 c2=1;
					 CustomDialog d= new CustomDialog(GameGUI.this,  "You can only attack Zombies that are adjacent to the selected Hero","Error",0);
		 				d.setVisible(true);
				}
	            setIcons(); 
	            setVisibility(); 
				if(c2==0) {
					 if(target.getCurrentHp()==0)
		                	heroDeath(target, GameGUI.this);
	            	refreshAttributesPanel2(x,y);}
				else {
					 if(target.getCurrentHp()==0)
		                	heroDeath(target, GameGUI.this);
					refreshAttributesPanel3(x,y);}
	            setVisibility();
	        }
	    }
	    }
	});
 
 cure.addActionListener(new ActionListener() {
	    public void actionPerformed(ActionEvent e) {
	    	 if(et==0) {
	    	if (target == null) {
	    		CustomDialog d= new CustomDialog(GameGUI.this,  "Please choose the Hero that will cure","Error",0);
 				d.setVisible(true);
	        } 
	        else if(target.getTarget()==null) {
	        	CustomDialog d= new CustomDialog(GameGUI.this,  "No zombie selected to cure","Error",0);
 				d.setVisible(true);
	        	}
	        
	        
	        else {
	        	Point p=target.getTarget().getLocation();
	        	int c2 = 0;
				try {
	        		
					((Hero) target).cure();
				} catch (NotEnoughActionsException e1) {
					f=1;
					c2=1;
					flashButtonColor(p.x,p.y,1);
					CustomDialog d= new CustomDialog(GameGUI.this,  "No action points left","Error",0);
	 				d.setVisible(true);
				} catch (InvalidTargetException e1) {
					f=1;
					c2=1;
					flashButtonColor(p.x,p.y,1);
					CustomDialog d= new CustomDialog(GameGUI.this,  "You can only cure Zombies that are adjacent","Error",0);
	 				d.setVisible(true);
				} catch (NoAvailableResourcesException e1) {
					f=1;
					c2=1;
					flashButtonColor(p.x,p.y,1);
					CustomDialog d= new CustomDialog(GameGUI.this,  "No Vaccines left in inventory","Error",0);
	 				d.setVisible(true);
				}
	        	f=c2;
	        	flashButtonColor(p.x,p.y,f);
	        	setIcons(); 
	            setVisibility(); 
	            refreshAttributesPanel4(x,y);
	            setVisibility();
	            
	        }
	    }
	    }
	});
 
 
 endturn.addActionListener(new ActionListener() {
	    public void actionPerformed(ActionEvent e) {
	        try {
	        	
				Game.endTurn();
				if(target!=null &&  target.getCurrentHp()==0) {
					target=null;
				}
				setIcons(); 
	            setVisibility();
	            refreshAttributesPanel3(x,y);
	           
	            
			} catch (NotEnoughActionsException e1) {
				setIcons(); 
	            setVisibility();
			} catch (InvalidTargetException e1) {
				setIcons(); 
	            setVisibility();
			}
	        setIcons(); 
            setVisibility();
            
            if (Game.checkWin() && br==0) {
            	br=1;
            	et=1;
            	GameGUI.mediaPlayer.pause();
                CustomDialog cd = new CustomDialog(GameGUI.this,"You won. How lucky.", "Winner",GameGUI.this);
                cd.setVisible(true);

                
                
                setIcons(); 
                setVisibility();
            }

            


           

            else if (Game.checkGameOver() && br==0) {
            	br=1;
            	et=1;
            	GameGUI.mediaPlayer.pause();
            	 CustomDialog cd = new CustomDialog(GameGUI.this,"This game is so easy. How did you even lose?", "Loser",GameGUI.this, GameGUI.this);
                 cd.setVisible(true);

                 
                 
                 setIcons(); 
                 setVisibility();
               
            }
            setIcons(); 
            setVisibility();

	        
	    }
	});


 
    }  
    
    private void playBackgroundMusic() {
        
        String musicFile = "bgm.mp3";
        Media sound = new Media(new File(musicFile).toURI().toString());

       
        MediaPlayer mediaPlayer = new MediaPlayer(sound);
        mediaPlayer.setCycleCount(MediaPlayer.INDEFINITE);

       
        mediaPlayer.play();
    }
    
    public static void setIcons() {
        
    	for (int row = 0; row < 15; row++) {
            for (int col = 0; col < 15; col++) {
                JButton cellButton = (JButton) gamePanel.getComponent(row * 15 + col); 
                Cell cell = Game.map[row][col];

                
                Object n;
				if (cell.isVisible()) { 
                    if (cell instanceof CharacterCell) {
                    	
                        Character character = (((CharacterCell) cell).getCharacter());
                        if(character==null)
                        	 cellButton.setIcon(null);
                        	
                        if (character instanceof Zombie) {
                        	 ImageIcon icon = new ImageIcon("zombie.png");
                             Image image = icon.getImage().getScaledInstance(40, 40, Image.SCALE_SMOOTH);
                             cellButton.setIcon(new ImageIcon(image));
                        } else if (character instanceof Hero) {
                            Hero h = (Hero) character;
                            n = h.getName();
                            
                            if (n.equals("Joel Miller")) {
                                ImageIcon icon = new ImageIcon("joel.png");
                                Image image = icon.getImage().getScaledInstance(40, 40, Image.SCALE_SMOOTH);
                                cellButton.setIcon(new ImageIcon(image));
                            } else if (n.equals("Ellie Williams")) {
                                ImageIcon icon = new ImageIcon("ellie.png");
                                Image image = icon.getImage().getScaledInstance(40, 40, Image.SCALE_SMOOTH);
                                cellButton.setIcon(new ImageIcon(image));
                            } else if (n.equals("Tess")) {
                                ImageIcon icon = new ImageIcon("tess.png");
                                Image image = icon.getImage().getScaledInstance(40, 40, Image.SCALE_SMOOTH);
                                cellButton.setIcon(new ImageIcon(image));
                            } else if (n.equals("Riley Abel")) {
                                ImageIcon icon = new ImageIcon("riley.png");
                                Image image = icon.getImage().getScaledInstance(40, 40, Image.SCALE_SMOOTH);
                                cellButton.setIcon(new ImageIcon(image));
                            } else if (n.equals("Tommy Miller")) {
                                ImageIcon icon = new ImageIcon("tommy.png");
                                Image image = icon.getImage().getScaledInstance(40, 40, Image.SCALE_SMOOTH);
                                cellButton.setIcon(new ImageIcon(image));
                            } else if (n.equals("Bill")) {
                                ImageIcon icon = new ImageIcon("bill.png");
                                Image image = icon.getImage().getScaledInstance(40, 40, Image.SCALE_SMOOTH);
                                cellButton.setIcon(new ImageIcon(image));
                            } else if (n.equals("David")) {
                                ImageIcon icon = new ImageIcon("david.png");
                                Image image = icon.getImage().getScaledInstance(40, 40, Image.SCALE_SMOOTH);
                                cellButton.setIcon(new ImageIcon(image));
                            } else if (n.equals("Henry Burell")) {
                                ImageIcon icon = new ImageIcon("henry.png");
                                Image image = icon.getImage().getScaledInstance(40, 40, Image.SCALE_SMOOTH);
                                cellButton.setIcon(new ImageIcon(image));
                            } else {
                                ImageIcon icon = new ImageIcon("else.png");
                                Image image = icon.getImage().getScaledInstance(40, 40, Image.SCALE_SMOOTH);
                                cellButton.setIcon(new ImageIcon(image));
                            }
                        }

                    } else if (cell instanceof CollectibleCell) {
                        Collectible collectible = ((CollectibleCell) cell).getCollectible();
                        if (collectible instanceof Supply) {
                            cellButton.setIcon(new ImageIcon("supply.jpg"));
                        } else if (collectible instanceof Vaccine) {
                            cellButton.setIcon(new ImageIcon("vaccine.png"));
                        }
                    } else {
                        cellButton.setIcon(null); 
                    }
                } else {
                    cellButton.setIcon(null); 
                }
                cellButton.setVisible(true);
            }
        }
    }
    public static void flashButtonColor(int x, int y, int c) {
        JButton cellButton = (JButton) gamePanel.getComponent(x * 15 + y); 

        Timer timer = new Timer(COLOR_CHANGE_DELAY, new ActionListener() {
            private boolean isColorGreen = false;
            private int flashCount = 0;

            
            public void actionPerformed(ActionEvent e) {
                if (isColorGreen) {
                    cellButton.setBackground(null);
                } else {
                	if(c==0)
                		cellButton.setBackground(new Color(0, 255, 0));
                	else
                		cellButton.setBackground(new Color(255, 0, 0));
                    flashCount++;
                }

                isColorGreen = !isColorGreen;

                if (flashCount >= 4) {
                    cellButton.setBackground(null);
                    ((Timer) e.getSource()).stop();
                }
            }
        });

        
        timer.start();
    }


    
   public static void setVisibility() {
        for (int row = 0; row < 15; row++) {
            for (int col = 0; col < 15; col++) {
                JButton cellButton = (JButton) gamePanel.getComponent(row * 15 + col); 
                Cell cell = Game.map[row][col];

                if (!cell.isVisible()) {
                    cellButton.setOpaque(true);
                    cellButton.setBackground(Color.BLACK);
                } else {
                    cellButton.setOpaque(false);
                    cellButton.setBackground(null);
                }
            }
        }
    }

    
    public void displayCharacterAttributes(int x, int y) {
        Cell cell = Game.map[x][y];
        
        if (cell instanceof CharacterCell ) {
            Character character = ((CharacterCell) cell).getCharacter();
           if(targettoheal==null && character instanceof Hero)
        	   target=character;
           if(character==null)
        	   target=null;
           
            if (character instanceof Fighter) {
                Fighter fighter = (Fighter) character;
                
                JLabel nameLabel = new JLabel("Name: " + fighter.getName());
                JLabel hpLabel = new JLabel("Current HP: " + fighter.getCurrentHp());
                JLabel attackLabel = new JLabel("Attack Damage: " + fighter.getAttackDmg());
                JLabel actionsLabel = new JLabel("Actions Available: " + fighter.getActionsAvailable());
                JLabel specialLabel = new JLabel("Special Action: " + fighter.isSpecialAction());
                JLabel supplyLabel = new JLabel("Supply Inventory Size: " + fighter.getSupplyInventory().size());
                JLabel vaccineLabel = new JLabel("Vaccine Inventory Size: " + fighter.getVaccineInventory().size());

                
                lowerPanel.removeAll();
                lowerPanel.setLayout(new GridLayout(6, 1));
                lowerPanel.add(nameLabel);
                lowerPanel.add(hpLabel);
                lowerPanel.add(attackLabel);
                lowerPanel.add(actionsLabel);
                lowerPanel.add(specialLabel);
                lowerPanel.add(supplyLabel);
                lowerPanel.add(vaccineLabel);

              
                lowerPanel.revalidate();
                lowerPanel.repaint();
            } else if (character instanceof Medic) {
                
            	Medic fighter = (Medic) character;
                
                JLabel nameLabel = new JLabel("Name: " + fighter.getName());
                JLabel hpLabel = new JLabel("Current HP: " + fighter.getCurrentHp());
                JLabel attackLabel = new JLabel("Attack Damage: " + fighter.getAttackDmg());
                JLabel actionsLabel = new JLabel("Actions Available: " + fighter.getActionsAvailable());
                JLabel specialLabel = new JLabel("Special Action: " + fighter.isSpecialAction());
                JLabel supplyLabel = new JLabel("Supply Inventory Size: " + fighter.getSupplyInventory().size());
                JLabel vaccineLabel = new JLabel("Vaccine Inventory Size: " + fighter.getVaccineInventory().size());

                
                lowerPanel.removeAll();
                lowerPanel.setLayout(new GridLayout(6, 1));
                lowerPanel.add(nameLabel);
                lowerPanel.add(hpLabel);
                lowerPanel.add(attackLabel);
                lowerPanel.add(actionsLabel);
                lowerPanel.add(specialLabel);
                lowerPanel.add(supplyLabel);
                lowerPanel.add(vaccineLabel);

               
                lowerPanel.revalidate();
                lowerPanel.repaint();
            } else if (character instanceof Explorer) {
                
            	Explorer fighter = (Explorer) character;
                
                JLabel nameLabel = new JLabel("Name: " + fighter.getName());
                JLabel hpLabel = new JLabel("Current HP: " + fighter.getCurrentHp());
                JLabel attackLabel = new JLabel("Attack Damage: " + fighter.getAttackDmg());
                JLabel actionsLabel = new JLabel("Actions Available: " + fighter.getActionsAvailable());
                JLabel specialLabel = new JLabel("Special Action: " + fighter.isSpecialAction());
                JLabel supplyLabel = new JLabel("Supply Inventory Size: " + fighter.getSupplyInventory().size());
                JLabel vaccineLabel = new JLabel("Vaccine Inventory Size: " + fighter.getVaccineInventory().size());

              
                lowerPanel.removeAll();
                lowerPanel.setLayout(new GridLayout(6, 1));
                lowerPanel.add(nameLabel);
                lowerPanel.add(hpLabel);
                lowerPanel.add(attackLabel);
                lowerPanel.add(actionsLabel);
                lowerPanel.add(specialLabel);
                lowerPanel.add(supplyLabel);
                lowerPanel.add(vaccineLabel);

                
                lowerPanel.revalidate();
                lowerPanel.repaint();
            }
        }
    }

    public void setZombieTarget(int x, int y) {
        
            
    		Cell cell = Game.map[x][y];
    		if(cell.isVisible()==false)
    			return;
            if (target!=null && target instanceof Hero && cell instanceof CharacterCell) {
                Character character = ((CharacterCell) cell).getCharacter();
                if (character instanceof Zombie) {
                    zombietarget = character;
                    target.setTarget(zombietarget);
                    refreshAttributesPanel(x,y);

                    return;
                }
            }
            
           
            zombietarget = null;
            if(target!=null)
            target.setTarget(null);
            refreshAttributesPanel(x,y);
            
         
    }

    public static void refreshAttributesPanel(int x, int y) {
        lowerPanel.removeAll();
        Cell cell = Game.map[x][y];

        if (cell instanceof CharacterCell && clicked == 1) {
            if (((CharacterCell) cell).getCharacter() instanceof Hero) {
                target = ((CharacterCell) cell).getCharacter();
            }
        } else
            target = null;

        if (target == null || cell instanceof CollectibleCell || cell instanceof TrapCell) {
            JLabel noneSelectedLabel = new JLabel("No hero selected");
            setLabelFormat(noneSelectedLabel);

            lowerPanel.removeAll();
            lowerPanel.setLayout(new GridLayout(6, 1));
            lowerPanel.add(noneSelectedLabel);
            lowerPanel.revalidate();
            lowerPanel.repaint();
            return;
        }

        JLabel targetLabel = new JLabel("No zombie selected ");
        JLabel zhp = new JLabel("zombie hp: No zombie selected");
        Character targ = null;
        JLabel empty = new JLabel();
        if (target != null)
            targ = target.getTarget();

        if (target instanceof Fighter) {
            Fighter fighter = (Fighter) target;

            JLabel nameLabel = new JLabel("Name: " + fighter.getName());
            JLabel hpLabel = new JLabel("Current HP: " + fighter.getCurrentHp());
            JLabel attackLabel = new JLabel("Attack Damage: " + fighter.getAttackDmg());
            JLabel actionsLabel = new JLabel("Actions Available: " + fighter.getActionsAvailable());
            JLabel specialLabel = new JLabel("Special Action: " + fighter.isSpecialAction());
            JLabel supplyLabel = new JLabel("Supply Inventory Size: " + fighter.getSupplyInventory().size());
            JLabel vaccineLabel = new JLabel("Vaccine Inventory Size: " + fighter.getVaccineInventory().size());
            

            if (targ != null) {
                targetLabel = new JLabel("Zombie targeted: " + targ.getName());
                zhp = new JLabel("zombie hp: " + targ.getCurrentHp());
            }
            setLabelFormat(nameLabel, hpLabel, attackLabel, actionsLabel, specialLabel, supplyLabel, vaccineLabel, targetLabel, zhp);

            lowerPanel.removeAll();
            lowerPanel.setLayout(new GridLayout(6, 1));
            lowerPanel.add(nameLabel);
            lowerPanel.add(hpLabel);
            lowerPanel.add(attackLabel);
            lowerPanel.add(actionsLabel);
            lowerPanel.add(specialLabel);
            lowerPanel.add(supplyLabel);
            lowerPanel.add(vaccineLabel);
            lowerPanel.add(targetLabel);
            lowerPanel.add(empty);
            lowerPanel.add(zhp);
            lowerPanel.revalidate();
            lowerPanel.repaint();
        } else if (target instanceof Medic) {

            Medic fighter = (Medic) target;

            JLabel nameLabel = new JLabel("Name: " + fighter.getName());
            JLabel hpLabel = new JLabel("Current HP: " + fighter.getCurrentHp());
            JLabel attackLabel = new JLabel("Attack Damage: " + fighter.getAttackDmg());
            JLabel actionsLabel = new JLabel("Actions Available: " + fighter.getActionsAvailable());
            JLabel specialLabel = new JLabel("Special Action: " + fighter.isSpecialAction());
            JLabel supplyLabel = new JLabel("Supply Inventory Size: " + fighter.getSupplyInventory().size());
            JLabel vaccineLabel = new JLabel("Vaccine Inventory Size: " + fighter.getVaccineInventory().size());


            if (targ != null) {
                zhp = new JLabel("zombie hp: " + targ.getCurrentHp());
                targetLabel = new JLabel("Zombie targeted: " + targ.getName());
            }
            setLabelFormat(nameLabel, hpLabel, attackLabel, actionsLabel, specialLabel, supplyLabel, vaccineLabel, targetLabel, zhp);

            lowerPanel.removeAll();
            lowerPanel.setLayout(new GridLayout(6, 1));
            lowerPanel.add(nameLabel);
            lowerPanel.add(hpLabel);
            lowerPanel.add(attackLabel);
            lowerPanel.add(actionsLabel);
            lowerPanel.add(specialLabel);
            lowerPanel.add(supplyLabel);
            lowerPanel.add(vaccineLabel);
            lowerPanel.add(targetLabel);
            lowerPanel.add(empty);
            lowerPanel.add(zhp);
            lowerPanel.revalidate();
            lowerPanel.repaint();
        } else if (target instanceof Explorer) {

            Explorer fighter = (Explorer) target;

            JLabel nameLabel = new JLabel("Name: " + fighter.getName());
            JLabel hpLabel = new JLabel("Current HP: " + fighter.getCurrentHp());
            JLabel attackLabel = new JLabel("Attack Damage: " + fighter.getAttackDmg());
            JLabel actionsLabel = new JLabel("Actions Available: " + fighter.getActionsAvailable());
            JLabel specialLabel = new JLabel("Special Action: " + fighter.isSpecialAction());
            JLabel supplyLabel = new JLabel("Supply Inventory Size: " + fighter.getSupplyInventory().size());
            JLabel vaccineLabel = new JLabel("Vaccine Inventory Size: " + fighter.getVaccineInventory().size());

            if (targ != null) {
                zhp = new JLabel("zombie hp: " + targ.getCurrentHp());
                targetLabel = new JLabel("Zombie targeted: " + targ.getName());
            }
            setLabelFormat(nameLabel, hpLabel, attackLabel, actionsLabel, specialLabel, supplyLabel, vaccineLabel, targetLabel, zhp);

            lowerPanel.removeAll();
            lowerPanel.setLayout(new GridLayout(6, 1));
            lowerPanel.add(nameLabel);
            lowerPanel.add(hpLabel);
            lowerPanel.add(attackLabel);
            lowerPanel.add(actionsLabel);
            lowerPanel.add(specialLabel);
            lowerPanel.add(supplyLabel);
            lowerPanel.add(vaccineLabel);
            lowerPanel.add(targetLabel);
            lowerPanel.add(empty);
            lowerPanel.add(zhp);
            lowerPanel.revalidate();
            lowerPanel.repaint();
        }
    }

    private static void setLabelFormat(JLabel... labels) {
        Font font = null;
        try {
            font = Font.createFont(Font.TRUETYPE_FONT, new File("font.ttf"));
            font = font.deriveFont(Font.PLAIN, 25f);
        } catch (FontFormatException | IOException e) {
            e.printStackTrace();
        }

        for (JLabel label : labels) {
            label.setFont(font);
            label.setForeground(Color.WHITE);
        }
    }
       
    
    private static void createHeroHealSelectionFrame() {
        JFrame heroSelectionFrame = new JFrame("Hero Selection");
        heroSelectionFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        heroSelectionFrame.setLayout(new BorderLayout());

        ImagePanel contentPane = new ImagePanel("c.jpg");
        contentPane.setLayout(new BorderLayout());

        JPanel heroSelectionPanel = new JPanel();
        heroSelectionPanel.setOpaque(false);
        heroSelectionPanel.setLayout(new GridLayout(4, 2, 10, 10));

        ArrayList<Hero> heroList = Game.heroes;
        final Hero[] selectedHero = new Hero[1];
        for (int i = 0; i < heroList.size(); i++) {
            Hero hero = heroList.get(i);
            String heroType;
            if (hero.getName().equals("Joel Miller") || hero.getName().equals("David"))
                heroType = "Fighter";
            else if (hero.getName().equals("Ellie Williams") || hero.getName().equals("Bill"))
                heroType = "Medic";
            else
                heroType = "Explorer";
            BackgroundImageButton heroButton = new BackgroundImageButton("bgg.jpg");
            heroButton.setPreferredSize(new Dimension(80, 40));
            heroButton.setBackgroundImage("bgg.jpg");
            heroButton.setForeground(Color.WHITE);
           
            heroButton.setCustomFont("font.ttf", Font.PLAIN, 25);
            heroButton.setText(hero.getName() + " (" + heroType + ")");
            heroButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                  
                    String heroAttributes = "Type: " + heroType + "\n" +
                            "Name: " + hero.getName() + "\n" +
                            "Max HP: " + hero.getMaxHp() + "\n" +
                            "Attack Damage: " + hero.getAttackDmg() + "\n" +
                            "Max Actions: " + hero.getMaxActions();

                   
                    Object[] options = {"Heal", "Back"};
                    AtomicInteger n = new AtomicInteger(0);
                   
                   CustomDialog customDialog = new CustomDialog(heroSelectionFrame, heroAttributes, "Hero Details"," ", n);
                   customDialog.setVisible(true);
                   int result = n.get();

                    if (result == 0) {
                        selectedHero[0] = hero;
                        count = 1;
                        target.setTarget(hero);
                        GameGUI g= gameGUI;
                        try {
                            ((Medic) target).useSpecial();
                             
                        } catch (NoAvailableResourcesException e1) {
                        	CustomDialog d= new CustomDialog(g, "No supplies left", "Error", 0);
                        	d.setVisible(true);
                        } catch (InvalidTargetException e1) {
                        	CustomDialog d= new CustomDialog(g, "You can only heal heroes, and they must be adjacent", "Error", 0);
                        	d.setVisible(true);
                        }


                        target.setTarget(null);
                        targettoheal = null;
                        setIcons();
                        setVisibility();
                        refreshAttributesPanel(x,y);
                    } else if (result == 1) {

                    }
                }
            });
            heroSelectionPanel.add(heroButton);
        }

        contentPane.add(heroSelectionPanel, BorderLayout.CENTER);
        heroSelectionFrame.setContentPane(contentPane);

        heroSelectionFrame.setSize(new Dimension(400, 300));
        heroSelectionFrame.setLocationRelativeTo(null);
        heroSelectionFrame.setVisible(true);
    }
    
    public static void refreshAttributesPanel2(int x, int y) {
        alternate = true;
        lowerPanel.removeAll();
        Cell cell = Game.map[x][y];
        if (cell instanceof CharacterCell && clicked==1) {
            if (((CharacterCell) cell).getCharacter() instanceof Hero) {
                target = ((CharacterCell) cell).getCharacter();
            }
        }
        
        else
        	target=null;
        
        JLabel targetLabel = new JLabel("No zombie selected ");
        JLabel zhp = new JLabel("zombie hp: No zombie selected");
        Character targ = null;
        JLabel empty = new JLabel();
        if (target != null)
            targ = target.getTarget();
        if (target == null) {
            JLabel noneSelectedLabel = new JLabel("No hero selected");

            lowerPanel.removeAll();
            lowerPanel.setLayout(new GridLayout(6, 1));
            lowerPanel.add(noneSelectedLabel);
            lowerPanel.revalidate();
            lowerPanel.repaint();
        }
        if (target instanceof Fighter) {
            Fighter fighter = (Fighter) target;

            JLabel nameLabel = new JLabel("Name: " + fighter.getName());
            JLabel hpLabel = new JLabel("Current HP: " + fighter.getCurrentHp());
            JLabel attackLabel = new JLabel("Attack Damage: " + fighter.getAttackDmg());
            JLabel actionsLabel = new JLabel("Actions Available: " + fighter.getActionsAvailable());
            JLabel specialLabel = new JLabel("Special Action: " + fighter.isSpecialAction());
            JLabel supplyLabel = new JLabel("Supply Inventory Size: " + fighter.getSupplyInventory().size());
            JLabel vaccineLabel = new JLabel("Vaccine Inventory Size: " + fighter.getVaccineInventory().size());

            if (targ != null) {
            	
                targetLabel = new JLabel("Zombie targeted: " + targ.getName());
                zhp = new JLabel("zombie hp: " + targ.getCurrentHp());
            }
            setLabelFormat(nameLabel, hpLabel, attackLabel, actionsLabel, specialLabel, supplyLabel, vaccineLabel, targetLabel, zhp);

            
             JLabel tp=targetLabel;
             JLabel z=zhp;
           
            Timer timer = new Timer(COLOR_CHANGE_DELAY, new ActionListener() {
                private boolean isColorRed = false;
                private int flashCount = 0;

                @Override
                public void actionPerformed(ActionEvent e) {
                    if (isColorRed && alternate == false) {
                    	 hpLabel.setForeground(Color.WHITE);
                         tp.setForeground(Color.WHITE);
                         z.setForeground(Color.WHITE);
                    } else {
                        hpLabel.setForeground(Color.RED);
                        tp.setForeground(Color.RED);
                        z.setForeground(Color.RED);
                        alternate = false;
                        flashCount++;
                    }

                    isColorRed = !isColorRed;

                    if (flashCount >= 4) {
                    	 hpLabel.setForeground(Color.WHITE);
                         tp.setForeground(Color.WHITE);
                         z.setForeground(Color.WHITE);
                        ((Timer) e.getSource()).stop();
                        
                    }
                }
            });

       
            timer.start();

            lowerPanel.removeAll();
            lowerPanel.setLayout(new GridLayout(6, 1));
            lowerPanel.add(nameLabel);
            lowerPanel.add(hpLabel);
            lowerPanel.add(attackLabel);
            lowerPanel.add(actionsLabel);
            lowerPanel.add(specialLabel);
            lowerPanel.add(supplyLabel);
            lowerPanel.add(vaccineLabel);
            lowerPanel.add(targetLabel);
            lowerPanel.add(empty);
            lowerPanel.add(zhp);

            lowerPanel.revalidate();
            lowerPanel.repaint();
        } else if (target instanceof Medic) {
        	JLabel tp=targetLabel;
            JLabel z=zhp;
            Medic fighter = (Medic) target;

            JLabel nameLabel = new JLabel("Name: " + fighter.getName());
            JLabel hpLabel = new JLabel("Current HP: " + fighter.getCurrentHp());
            JLabel attackLabel = new JLabel("Attack Damage: " + fighter.getAttackDmg());
            JLabel actionsLabel = new JLabel("Actions Available: " + fighter.getActionsAvailable());
            JLabel specialLabel = new JLabel("Special Action: " + fighter.isSpecialAction());
            JLabel supplyLabel = new JLabel("Supply Inventory Size: " + fighter.getSupplyInventory().size());
            JLabel vaccineLabel = new JLabel("Vaccine Inventory Size: " + fighter.getVaccineInventory().size());
            if (targ != null) {
                zhp = new JLabel("zombie hp: " + targ.getCurrentHp());
                targetLabel = new JLabel("Zombie targeted: " + targ.getName());
            }

            setLabelFormat(nameLabel, hpLabel, attackLabel, actionsLabel, specialLabel, supplyLabel, vaccineLabel, targetLabel, zhp);

            Timer timer = new Timer(COLOR_CHANGE_DELAY, new ActionListener() {
                private boolean isColorRed = false;
                private int flashCount = 0;

                @Override
                public void actionPerformed(ActionEvent e) {
                    if (isColorRed && alternate == false) {
                    	 hpLabel.setForeground(Color.WHITE);
                         tp.setForeground(Color.WHITE);
                         z.setForeground(Color.WHITE);
                    } else {
                        hpLabel.setForeground(Color.RED);
                        tp.setForeground(Color.RED);
                        z.setForeground(Color.RED);
                        alternate = false;
                        flashCount++;
                    }

                    isColorRed = !isColorRed;

                    if (flashCount >= 4) {
                    	 hpLabel.setForeground(Color.WHITE);
                         tp.setForeground(Color.WHITE);
                         z.setForeground(Color.WHITE);
                        ((Timer) e.getSource()).stop();
                    }
                }
            });

           
            timer.start();

            lowerPanel.removeAll();
            lowerPanel.setLayout(new GridLayout(6, 1));
            lowerPanel.add(nameLabel);
            lowerPanel.add(hpLabel);
            lowerPanel.add(attackLabel);
            lowerPanel.add(actionsLabel);
            lowerPanel.add(specialLabel);
            lowerPanel.add(supplyLabel);
            lowerPanel.add(vaccineLabel);
            lowerPanel.add(targetLabel);
            lowerPanel.add(empty);
            lowerPanel.add(zhp);
            lowerPanel.revalidate();
            lowerPanel.repaint();
        } else if (target instanceof Explorer) {
        	JLabel tp=targetLabel;
            JLabel z=zhp;
            Explorer fighter = (Explorer) target;

            JLabel nameLabel = new JLabel("Name: " + fighter.getName());
            JLabel hpLabel = new JLabel("Current HP: " + fighter.getCurrentHp());
            JLabel attackLabel = new JLabel("Attack Damage: " + fighter.getAttackDmg());
            JLabel actionsLabel = new JLabel("Actions Available: " + fighter.getActionsAvailable());
            JLabel specialLabel = new JLabel("Special Action: " + fighter.isSpecialAction());
            JLabel supplyLabel = new JLabel("Supply Inventory Size: " + fighter.getSupplyInventory().size());
            JLabel vaccineLabel = new JLabel("Vaccine Inventory Size: " + fighter.getVaccineInventory().size());
            if (targ != null) {
                zhp = new JLabel("zombie hp: " + targ.getCurrentHp());
                targetLabel = new JLabel("Zombie targeted: " + targ.getName());
            }

            setLabelFormat(nameLabel, hpLabel, attackLabel, actionsLabel, specialLabel, supplyLabel, vaccineLabel, targetLabel, zhp);

            Timer timer = new Timer(COLOR_CHANGE_DELAY, new ActionListener() {
                private boolean isColorRed = false;
                private int flashCount = 0;

                @Override
                public void actionPerformed(ActionEvent e) {
                    if (isColorRed && alternate == false) {
                        hpLabel.setForeground(Color.WHITE);
                        tp.setForeground(Color.WHITE);
                        z.setForeground(Color.WHITE);
                    } else {
                        hpLabel.setForeground(Color.RED);
                        tp.setForeground(Color.RED);
                        z.setForeground(Color.RED);
                        alternate = false;
                        flashCount++;
                    }

                    isColorRed = !isColorRed;

                    if (flashCount >= 4) {
                    	hpLabel.setForeground(Color.WHITE);
                    	tp.setForeground(Color.WHITE);
                        z.setForeground(Color.WHITE);
                        ((Timer) e.getSource()).stop();
                    }
                }
            });

         
            timer.start();

            lowerPanel.removeAll();
            lowerPanel.setLayout(new GridLayout(6, 1));
            lowerPanel.add(nameLabel);
            lowerPanel.add(hpLabel);
            lowerPanel.add(attackLabel);
            lowerPanel.add(actionsLabel);
            lowerPanel.add(specialLabel);
            lowerPanel.add(supplyLabel);
            lowerPanel.add(vaccineLabel);
            lowerPanel.add(targetLabel);
            lowerPanel.add(empty);
            lowerPanel.add(zhp);
            lowerPanel.revalidate();
            lowerPanel.repaint();
        }
    }

    public static void refreshAttributesPanel3(int x, int y) {
        alternate = true;
        lowerPanel.removeAll();
        Cell cell = Game.map[x][y];
        if (cell instanceof CharacterCell && clicked==1) {
            if (((CharacterCell) cell).getCharacter() instanceof Hero) {
                target = ((CharacterCell) cell).getCharacter();
            }
        }
        
        else
        	target=null;
        JLabel targetLabel = new JLabel("No zombie selected ");
        JLabel zhp = new JLabel("zombie hp: No zombie selected to show Hp");
        Character targ = null;
        JLabel empty = new JLabel();
        if (target != null)
            targ = target.getTarget();
        if (target == null) {
            JLabel noneSelectedLabel = new JLabel("No hero selected");

            lowerPanel.removeAll();
            lowerPanel.setLayout(new GridLayout(6, 1));
            lowerPanel.add(noneSelectedLabel);
            lowerPanel.revalidate();
            lowerPanel.repaint();
        }
        if (target instanceof Fighter) {
            Fighter fighter = (Fighter) target;

            JLabel nameLabel = new JLabel("Name: " + fighter.getName());
            JLabel hpLabel = new JLabel("Current HP: " + fighter.getCurrentHp());
            JLabel attackLabel = new JLabel("Attack Damage: " + fighter.getAttackDmg());
            JLabel actionsLabel = new JLabel("Actions Available: " + fighter.getActionsAvailable());
            JLabel specialLabel = new JLabel("Special Action: " + fighter.isSpecialAction());
            JLabel supplyLabel = new JLabel("Supply Inventory Size: " + fighter.getSupplyInventory().size());
            JLabel vaccineLabel = new JLabel("Vaccine Inventory Size: " + fighter.getVaccineInventory().size());

            if (targ != null) {
                targetLabel = new JLabel("Zombie targeted: " + targ.getName());
                zhp = new JLabel("zombie hp: " + targ.getCurrentHp());
            }
            setLabelFormat(nameLabel, hpLabel, attackLabel, actionsLabel, specialLabel, supplyLabel, vaccineLabel, targetLabel, zhp);

           
            Timer timer = new Timer(COLOR_CHANGE_DELAY, new ActionListener() {
                private boolean isColorRed = false;
                private int flashCount = 0;

                @Override
                public void actionPerformed(ActionEvent e) {
                    if (isColorRed && alternate == false) {
                        hpLabel.setForeground(Color.WHITE);
                    } else {
                        hpLabel.setForeground(Color.YELLOW);
                        alternate = false;
                        flashCount++;
                    }

                    isColorRed = !isColorRed;

                    if (flashCount >= 4) {
                    	hpLabel.setForeground(Color.WHITE);
                        ((Timer) e.getSource()).stop();
                    }
                }
            });

            
            timer.start();

            lowerPanel.removeAll();
            lowerPanel.setLayout(new GridLayout(6, 1));
            lowerPanel.add(nameLabel);
            lowerPanel.add(hpLabel);
            lowerPanel.add(attackLabel);
            lowerPanel.add(actionsLabel);
            lowerPanel.add(specialLabel);
            lowerPanel.add(supplyLabel);
            lowerPanel.add(vaccineLabel);
            lowerPanel.add(targetLabel);
            lowerPanel.add(empty);
            lowerPanel.add(zhp);

            lowerPanel.revalidate();
            lowerPanel.repaint();
        } else if (target instanceof Medic) {

            Medic fighter = (Medic) target;

            JLabel nameLabel = new JLabel("Name: " + fighter.getName());
            JLabel hpLabel = new JLabel("Current HP: " + fighter.getCurrentHp());
            JLabel attackLabel = new JLabel("Attack Damage: " + fighter.getAttackDmg());
            JLabel actionsLabel = new JLabel("Actions Available: " + fighter.getActionsAvailable());
            JLabel specialLabel = new JLabel("Special Action: " + fighter.isSpecialAction());
            JLabel supplyLabel = new JLabel("Supply Inventory Size: " + fighter.getSupplyInventory().size());
            JLabel vaccineLabel = new JLabel("Vaccine Inventory Size: " + fighter.getVaccineInventory().size());
            if (targ != null) {
                zhp = new JLabel("zombie hp: " + targ.getCurrentHp());
                targetLabel = new JLabel("Zombie targeted: " + targ.getName());
            }
            setLabelFormat(nameLabel, hpLabel, attackLabel, actionsLabel, specialLabel, supplyLabel, vaccineLabel, targetLabel, zhp);

           
            Timer timer = new Timer(COLOR_CHANGE_DELAY, new ActionListener() {
                private boolean isColorRed = false;
                private int flashCount = 0;

                @Override
                public void actionPerformed(ActionEvent e) {
                    if (isColorRed && alternate == false) {
                        hpLabel.setForeground(Color.WHITE);
                    } else {
                        hpLabel.setForeground(Color.YELLOW);
                        alternate = false;
                        flashCount++;
                    }

                    isColorRed = !isColorRed;

                    if (flashCount >= 4) {
                    	hpLabel.setForeground(Color.WHITE);
                        ((Timer) e.getSource()).stop();
                    }
                }
            });

            timer.start();

            lowerPanel.removeAll();
            lowerPanel.setLayout(new GridLayout(6, 1));
            lowerPanel.add(nameLabel);
            lowerPanel.add(hpLabel);
            lowerPanel.add(attackLabel);
            lowerPanel.add(actionsLabel);
            lowerPanel.add(specialLabel);
            lowerPanel.add(supplyLabel);
            lowerPanel.add(vaccineLabel);
            lowerPanel.add(targetLabel);
            lowerPanel.add(empty);
            lowerPanel.add(zhp);
            lowerPanel.revalidate();
            lowerPanel.repaint();
        } else if (target instanceof Explorer) {

            Explorer fighter = (Explorer) target;

            JLabel nameLabel = new JLabel("Name: " + fighter.getName());
            JLabel hpLabel = new JLabel("Current HP: " + fighter.getCurrentHp());
            JLabel attackLabel = new JLabel("Attack Damage: " + fighter.getAttackDmg());
            JLabel actionsLabel = new JLabel("Actions Available: " + fighter.getActionsAvailable());
            JLabel specialLabel = new JLabel("Special Action: " + fighter.isSpecialAction());
            JLabel supplyLabel = new JLabel("Supply Inventory Size: " + fighter.getSupplyInventory().size());
            JLabel vaccineLabel = new JLabel("Vaccine Inventory Size: " + fighter.getVaccineInventory().size());
            if (targ != null) {
                zhp = new JLabel("zombie hp: " + targ.getCurrentHp());
                targetLabel = new JLabel("Zombie targeted: " + targ.getName());
            }
            setLabelFormat(nameLabel, hpLabel, attackLabel, actionsLabel, specialLabel, supplyLabel, vaccineLabel, targetLabel, zhp);

            Timer timer = new Timer(COLOR_CHANGE_DELAY, new ActionListener() {
                private boolean isColorRed = false;
                private int flashCount = 0;

                @Override
                public void actionPerformed(ActionEvent e) {
                    if (isColorRed && alternate == false) {
                        hpLabel.setForeground(Color.WHITE);
                    } else {
                        hpLabel.setForeground(Color.YELLOW);
                        alternate = false;
                        flashCount++;
                    }

                    isColorRed = !isColorRed;

                    if (flashCount >= 4) {
                    	hpLabel.setForeground(Color.WHITE);
                        ((Timer) e.getSource()).stop();
                    }
                }
            });
            timer.start();

            lowerPanel.removeAll();
            lowerPanel.setLayout(new GridLayout(6, 1));
            lowerPanel.add(nameLabel);
            lowerPanel.add(hpLabel);
            lowerPanel.add(attackLabel);
            lowerPanel.add(actionsLabel);
            lowerPanel.add(specialLabel);
            lowerPanel.add(supplyLabel);
            lowerPanel.add(vaccineLabel);
            lowerPanel.add(targetLabel);
            lowerPanel.add(empty);
            lowerPanel.add(zhp);
            lowerPanel.revalidate();
            lowerPanel.repaint();
        }
    }

    public static void refreshAttributesPanel4(int x, int y) {
        alternate = true;
        lowerPanel.removeAll();
        Cell cell = Game.map[x][y];
        if (cell instanceof CharacterCell && clicked==1) {
            if (((CharacterCell) cell).getCharacter() instanceof Hero) {
                target = ((CharacterCell) cell).getCharacter();
            }
        }
       
        else
        	target=null;
        JLabel targetLabel = new JLabel("No zombie selected ");
        JLabel zhp = new JLabel("zombie hp: No zombie selected to show Hp");
        Character targ = null;
        JLabel empty = new JLabel();
        if (target != null)
            targ = target.getTarget();
        if (target == null) {
            JLabel noneSelectedLabel = new JLabel("No hero selected");

            lowerPanel.removeAll();
            lowerPanel.setLayout(new GridLayout(6, 1));
            lowerPanel.add(noneSelectedLabel);
            lowerPanel.revalidate();
            lowerPanel.repaint();
        }
        if (target instanceof Fighter) {
            Fighter fighter = (Fighter) target;

            JLabel nameLabel = new JLabel("Name: " + fighter.getName());
            JLabel hpLabel = new JLabel("Current HP: " + fighter.getCurrentHp());
            JLabel attackLabel = new JLabel("Attack Damage: " + fighter.getAttackDmg());
            JLabel actionsLabel = new JLabel("Actions Available: " + fighter.getActionsAvailable());
            JLabel specialLabel = new JLabel("Special Action: " + fighter.isSpecialAction());
            JLabel supplyLabel = new JLabel("Supply Inventory Size: " + fighter.getSupplyInventory().size());
            JLabel vaccineLabel = new JLabel("Vaccine Inventory Size: " + fighter.getVaccineInventory().size());

            if (targ != null) {
            	
                targetLabel = new JLabel("Zombie targeted: " + targ.getName());
                zhp = new JLabel("zombie hp: " + targ.getCurrentHp());
            }
            setLabelFormat(nameLabel, hpLabel, attackLabel, actionsLabel, specialLabel, supplyLabel, vaccineLabel, targetLabel, zhp);

             JLabel tp=targetLabel;
             JLabel z=zhp;
           
            Timer timer = new Timer(COLOR_CHANGE_DELAY, new ActionListener() {
                private boolean isColorRed = false;
                private int flashCount = 0;

                @Override
                public void actionPerformed(ActionEvent e) {
                    if (isColorRed && alternate == false) {
                    	hpLabel.setForeground(Color.WHITE);
                        tp.setForeground(Color.WHITE);
                        z.setForeground(Color.WHITE);
                        nameLabel.setForeground(Color.WHITE);
                        attackLabel.setForeground(Color.WHITE);
                        actionsLabel.setForeground(Color.WHITE);
                        specialLabel.setForeground(Color.WHITE);
                        supplyLabel.setForeground(Color.WHITE);
                        vaccineLabel.setForeground(Color.WHITE);
                        
                    } else {
                    	hpLabel.setForeground(Color.GREEN);
                    	tp.setForeground(Color.GREEN);
                    	z.setForeground(Color.GREEN);
                    	nameLabel.setForeground(Color.GREEN);
                    	attackLabel.setForeground(Color.GREEN);
                    	actionsLabel.setForeground(Color.GREEN);
                    	specialLabel.setForeground(Color.GREEN);
                    	supplyLabel.setForeground(Color.GREEN);
                    	vaccineLabel.setForeground(Color.GREEN);
                        alternate = false;
                        flashCount++;
                    }

                    isColorRed = !isColorRed;

                    if (flashCount >= 4) {
                    	hpLabel.setForeground(Color.WHITE);
                        tp.setForeground(Color.WHITE);
                        z.setForeground(Color.WHITE);
                        nameLabel.setForeground(Color.WHITE);
                        attackLabel.setForeground(Color.WHITE);
                        actionsLabel.setForeground(Color.WHITE);
                        specialLabel.setForeground(Color.WHITE);
                        supplyLabel.setForeground(Color.WHITE);
                        vaccineLabel.setForeground(Color.WHITE);
                        ((Timer) e.getSource()).stop();
                        
                    }
                }
            });

            timer.start();

            lowerPanel.removeAll();
            lowerPanel.setLayout(new GridLayout(6, 1));
            lowerPanel.add(nameLabel);
            lowerPanel.add(hpLabel);
            lowerPanel.add(attackLabel);
            lowerPanel.add(actionsLabel);
            lowerPanel.add(specialLabel);
            lowerPanel.add(supplyLabel);
            lowerPanel.add(vaccineLabel);
            lowerPanel.add(targetLabel);
            lowerPanel.add(empty);
            lowerPanel.add(zhp);

            lowerPanel.revalidate();
            lowerPanel.repaint();
        } else if (target instanceof Medic) {
        	JLabel tp=targetLabel;
            JLabel z=zhp;
            Medic fighter = (Medic) target;

            JLabel nameLabel = new JLabel("Name: " + fighter.getName());
            JLabel hpLabel = new JLabel("Current HP: " + fighter.getCurrentHp());
            JLabel attackLabel = new JLabel("Attack Damage: " + fighter.getAttackDmg());
            JLabel actionsLabel = new JLabel("Actions Available: " + fighter.getActionsAvailable());
            JLabel specialLabel = new JLabel("Special Action: " + fighter.isSpecialAction());
            JLabel supplyLabel = new JLabel("Supply Inventory Size: " + fighter.getSupplyInventory().size());
            JLabel vaccineLabel = new JLabel("Vaccine Inventory Size: " + fighter.getVaccineInventory().size());
            if (targ != null) {
                zhp = new JLabel("zombie hp: " + targ.getCurrentHp());
                targetLabel = new JLabel("Zombie targeted: " + targ.getName());
            }
            setLabelFormat(nameLabel, hpLabel, attackLabel, actionsLabel, specialLabel, supplyLabel, vaccineLabel, targetLabel, zhp);

            Timer timer = new Timer(COLOR_CHANGE_DELAY, new ActionListener() {
                private boolean isColorRed = false;
                private int flashCount = 0;

                @Override
                public void actionPerformed(ActionEvent e) {
                    if (isColorRed && alternate == false) {
                    	hpLabel.setForeground(Color.WHITE);
                        tp.setForeground(Color.WHITE);
                        z.setForeground(Color.WHITE);
                        nameLabel.setForeground(Color.WHITE);
                        attackLabel.setForeground(Color.WHITE);
                        actionsLabel.setForeground(Color.WHITE);
                        specialLabel.setForeground(Color.WHITE);
                        supplyLabel.setForeground(Color.WHITE);
                        vaccineLabel.setForeground(Color.WHITE);
                    } else {
                    	hpLabel.setForeground(Color.GREEN);
                    	tp.setForeground(Color.GREEN);
                    	z.setForeground(Color.GREEN);
                    	nameLabel.setForeground(Color.GREEN);
                    	attackLabel.setForeground(Color.GREEN);
                    	actionsLabel.setForeground(Color.GREEN);
                    	specialLabel.setForeground(Color.GREEN);
                    	supplyLabel.setForeground(Color.GREEN);
                    	vaccineLabel.setForeground(Color.GREEN);
                        alternate = false;
                        flashCount++;
                    }

                    isColorRed = !isColorRed;

                    if (flashCount >= 4) {
                    	hpLabel.setForeground(Color.WHITE);
                        tp.setForeground(Color.WHITE);
                        z.setForeground(Color.WHITE);
                        nameLabel.setForeground(Color.WHITE);
                        attackLabel.setForeground(Color.WHITE);
                        actionsLabel.setForeground(Color.WHITE);
                        specialLabel.setForeground(Color.WHITE);
                        supplyLabel.setForeground(Color.WHITE);
                        vaccineLabel.setForeground(Color.WHITE);
                        ((Timer) e.getSource()).stop();
                    }
                }
            });

            timer.start();

            lowerPanel.removeAll();
            lowerPanel.setLayout(new GridLayout(6, 1));
            lowerPanel.add(nameLabel);
            lowerPanel.add(hpLabel);
            lowerPanel.add(attackLabel);
            lowerPanel.add(actionsLabel);
            lowerPanel.add(specialLabel);
            lowerPanel.add(supplyLabel);
            lowerPanel.add(vaccineLabel);
            lowerPanel.add(targetLabel);
            lowerPanel.add(empty);
            lowerPanel.add(zhp);
            lowerPanel.revalidate();
            lowerPanel.repaint();
        } else if (target instanceof Explorer) {
        	JLabel tp=targetLabel;
            JLabel z=zhp;
            Explorer fighter = (Explorer) target;

            JLabel nameLabel = new JLabel("Name: " + fighter.getName());
            JLabel hpLabel = new JLabel("Current HP: " + fighter.getCurrentHp());
            JLabel attackLabel = new JLabel("Attack Damage: " + fighter.getAttackDmg());
            JLabel actionsLabel = new JLabel("Actions Available: " + fighter.getActionsAvailable());
            JLabel specialLabel = new JLabel("Special Action: " + fighter.isSpecialAction());
            JLabel supplyLabel = new JLabel("Supply Inventory Size: " + fighter.getSupplyInventory().size());
            JLabel vaccineLabel = new JLabel("Vaccine Inventory Size: " + fighter.getVaccineInventory().size());
            if (targ != null) {
                zhp = new JLabel("zombie hp: " + targ.getCurrentHp());
                targetLabel = new JLabel("Zombie targeted: " + targ.getName());
            }
            setLabelFormat(nameLabel, hpLabel, attackLabel, actionsLabel, specialLabel, supplyLabel, vaccineLabel, targetLabel, zhp);

            Timer timer = new Timer(COLOR_CHANGE_DELAY, new ActionListener() {
                private boolean isColorRed = false;
                private int flashCount = 0;

                @Override
                public void actionPerformed(ActionEvent e) {
                    if (isColorRed && alternate == false) {
                    	hpLabel.setForeground(Color.WHITE);
                        tp.setForeground(Color.WHITE);
                        z.setForeground(Color.WHITE);
                        nameLabel.setForeground(Color.WHITE);
                        attackLabel.setForeground(Color.WHITE);
                        actionsLabel.setForeground(Color.WHITE);
                        specialLabel.setForeground(Color.WHITE);
                        supplyLabel.setForeground(Color.WHITE);
                        vaccineLabel.setForeground(Color.WHITE);
                    } else {
                    	hpLabel.setForeground(Color.GREEN);
                    	tp.setForeground(Color.GREEN);
                    	z.setForeground(Color.GREEN);
                    	nameLabel.setForeground(Color.GREEN);
                    	attackLabel.setForeground(Color.GREEN);
                    	actionsLabel.setForeground(Color.GREEN);
                    	specialLabel.setForeground(Color.GREEN);
                    	supplyLabel.setForeground(Color.GREEN);
                    	vaccineLabel.setForeground(Color.GREEN);
                        alternate = false;
                        flashCount++;
                    }

                    isColorRed = !isColorRed;

                    if (flashCount >= 4) {
                    	hpLabel.setForeground(Color.WHITE);
                        tp.setForeground(Color.WHITE);
                        z.setForeground(Color.WHITE);
                        nameLabel.setForeground(Color.WHITE);
                        attackLabel.setForeground(Color.WHITE);
                        actionsLabel.setForeground(Color.WHITE);
                        specialLabel.setForeground(Color.WHITE);
                        supplyLabel.setForeground(Color.WHITE);
                        vaccineLabel.setForeground(Color.WHITE);
                        ((Timer) e.getSource()).stop();
                    }
                }
            });

            timer.start();

            lowerPanel.removeAll();
            lowerPanel.setLayout(new GridLayout(6, 1));
            lowerPanel.add(nameLabel);
            lowerPanel.add(hpLabel);
            lowerPanel.add(attackLabel);
            lowerPanel.add(actionsLabel);
            lowerPanel.add(specialLabel);
            lowerPanel.add(supplyLabel);
            lowerPanel.add(vaccineLabel);
            lowerPanel.add(targetLabel);
            lowerPanel.add(empty);
            lowerPanel.add(zhp);
            lowerPanel.revalidate();
            lowerPanel.repaint();
        }
    }
    	
    public static void heroDeath(Character h, GameGUI g) {
    	JOptionPane.showMessageDialog(null, h.getName() + " " + "Has died");
    	
    	CustomDialog d= new CustomDialog(g, h.getName() + " " + "Has died", "Hero Death", 0);
    	d.setVisible(true);
    	Game.map[h.getLocation().x][h.getLocation().y].setVisible(true);
    	setVisibility();
    }
    
    public void showReadyDialog() {

    	CustomDialog dialog = new CustomDialog(this, "Are you ready?", "I DONT HAVE MUCH TIME, RUN AWA-");
    	dialog.setVisible(true);
    	setIcons();
    	setVisibility();
    	
       
    }
    
    public MediaPlayer getPlayer() {
    	return this.mediaPlayer;
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                try {
                    GameGUI gameGUI = new GameGUI();
                    
                    gameGUI.setTitle("TLoU:Legacy");
                    
                    Image logo = Toolkit.getDefaultToolkit().getImage("logo.png");
                    gameGUI.setIconImage(logo);
                    
                    GameGUI.setIcons();
                    GameGUI.setVisibility();
                    
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        JFXPanel fxPanel = new JFXPanel();
        Application.launch(JavaFXApplication.class, args);
    }

    public void startframe() {
    	SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                try {
                    GameGUI gameGUI = new GameGUI();
                    
                    gameGUI.setTitle("TLoU:Legacy");
                    
             
                    Image logo = Toolkit.getDefaultToolkit().getImage("logo.png");
                    gameGUI.setIconImage(logo);
                    
                    GameGUI.setIcons();
                    GameGUI.setVisibility();
                    
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    	JFXPanel fxPanel = new JFXPanel();
        Application.launch(JavaFXApplication.class, null);
    }

    public static class JavaFXApplication extends Application {
        @Override
        public void start(Stage primaryStage) {
            
        }
    }

} 
